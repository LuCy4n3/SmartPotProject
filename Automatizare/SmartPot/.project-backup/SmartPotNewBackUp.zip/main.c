#include <atmel_start.h>
#include <util/delay.h>
#include "SpecialLibraries/SHT31.h"
int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	USART_1_init();
	USART_1_enable();
	USART_1_enable_tx();
	USART_1_write('i');
	PORTA_set_pin_dir(4,PORT_DIR_OUT);
	//DELAY_milliseconds(500);
	/* Replace with your application code */
	while (1) {
			PORTA_toggle_pin_level(4);
			USART_1_write('a');
			USART_1_write(testFunct('c'));
			//PORTC_toggle_pin_level(2);
			_delay_ms(2000);
	}
}
